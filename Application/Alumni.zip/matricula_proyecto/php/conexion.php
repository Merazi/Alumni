<?php 
	$conexion = mysqli_connect("localhost", "root", "", "proyecto_matricula");
	
    /*
    if($conexion){
	echo 'conectado exitosamente a la base de datos';
	}else{
	echo 'no se ha podido conectar';
	}
    */
    



?>